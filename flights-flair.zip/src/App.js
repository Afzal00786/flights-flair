import "./App.css";
import Navigation from "./Navigation.js";

function App() {
  return (
    <>
      <Navigation />
    </>
  );
}

export default App;
