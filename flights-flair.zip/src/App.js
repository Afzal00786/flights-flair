import logo from "./logo.svg";
import "./App.css";
import Home from "../src/components/Home";
import BookNow from "../src/components/BookNow";
import Navigation from "./Navigation.js";

function App() {
  return (
    <>
      <Navigation />
    </>
  );
}

export default App;
